#include <Arduino.h>
#include <librobus.h>
int tourner (void);
int Stop (void);
int avancer (void);
void setup() {
  // put your setup code here, to run once:
  BoardInit();
  tourner();
  //avancer();
}

void loop() {
  // put your main code here, to run repeatedly:
  //tourner();
  //delay(1000);
  //Stop();
}
int avancer (void)
{
  uint16_t toto; 
  ENCODER_Reset(0);
  ENCODER_Reset(1);
  MOTOR_SetSpeed(0, 0.3f);
  MOTOR_SetSpeed(1, 0.3f);
  while ((ENCODER_Read(0)<= 340) && ENCODER_Read(1)<= 340)
  {
    toto = ENCODER_Read(0);
    //Serial.write(toto);
  }
  MOTOR_SetSpeed(0, 0.0f);
  MOTOR_SetSpeed(1, 0.0f);
  return 0;
}
int tourner (void)
{
  uint32_t toto; 
  ENCODER_Reset(0);
  ENCODER_Reset(1);
  MOTOR_SetSpeed(0, 0.3f);
  MOTOR_SetSpeed(1, -0.3f);
  while ((ENCODER_Read(0)<= 7800))
  {
    toto = ENCODER_Read(1);
    Serial.write(toto);
  }
  MOTOR_SetSpeed(0, 0.0f);
  MOTOR_SetSpeed(1, 0.0f);
  return 0;
};

int Stop (void)
{

  MOTOR_SetSpeed(0, 0.0f);
  MOTOR_SetSpeed(1, 0.0f);

  return 0;
};